// This interface is used by Assig4 driver class to make a call back to 
// the object main program that initiated it. 

/**
 * @author 21gjulio30
 * Gianna Julio
 * period 4 - Java
 * NewPlayerInterface
 */
public interface NewPlayerInterface
{
	public abstract void loginNewPlayer(Player pl);
}
